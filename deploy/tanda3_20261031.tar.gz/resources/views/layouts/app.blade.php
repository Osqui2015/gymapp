<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'GymApp') }}</title>

        {{-- PWA (Progressive Web App) --}}
        <link rel="manifest" href="/manifest.webmanifest">
        <meta name="theme-color" content="#4f46e5">
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <meta name="apple-mobile-web-app-title" content="GymApp">
        <link rel="icon" href="/favicon.ico">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet" />
        {{-- Phosphor Icons for high-end fitness UI (Kinetic Obsidian) --}}
        <script src="https://unpkg.com/@phosphor-icons/web"></script>

        {{-- Script anti-FOUC: aplica el tema antes de que Vue hidrate --}}
        <script>
            (function () {
                try {
                    // Soporta ambas keys para retrocompat: 'theme' (vieja) y 'theme_mode' (nueva)
                    var mode = localStorage.getItem('theme_mode') || localStorage.getItem('theme') || 'auto';
                    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
                    var dark = mode === 'dark' || (mode === 'auto' && prefersDark);
                    if (dark) document.documentElement.classList.add('dark');
                } catch (e) {}
            })();
        </script>

        {{-- Config pública de broadcasting (Mejora 8.1) --}}
        <script>
            window.__broadcasting = {
                driver: @json(config('services.broadcasting.driver', 'null')),
                key: @json(config('services.broadcasting.pusher.key')),
                cluster: @json(config('services.broadcasting.pusher.options.cluster')),
            };
            window.__user = window.__user || {
                id: @json(auth()->id()),
                name: @json(auth()->user()?->name ?? ''),
                nick: @json(auth()->user()?->nick ?? ''),
            };
        </script>

        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans antialiased bg-[#0B0F17] text-slate-200 selection:bg-indigo-500 selection:text-white overflow-x-hidden">
        {{-- Skip to content (a11y: 6.3) --}}
        <a
            href="#main-content"
            class="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[60] focus:px-4 focus:py-2 focus:bg-violet-600 focus:text-white focus:rounded-lg focus:shadow-lg focus:font-semibold"
        >
            Saltar al contenido principal
        </a>

        <div class="min-h-screen bg-[#0B0F17] pb-20 md:pb-0">
            @include('layouts.navigation')

            @isset($header)
                {{-- Wrapper de header transparente y sin padding extra en mobile.
                     Las pantallas con su propio top-bar mobile (Dashboard, Historial,
                     Progreso, Rutinas) ocultan el contenido del slot con hidden md:block.
                     Las pantallas sin top-bar (Profile, Ejercicios, etc.) lo muestran acá. --}}
                <header class="bg-transparent dark:bg-transparent border-0">
                    <div class="max-w-7xl mx-auto py-0 md:py-6 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endisset

            <main id="app" class="overflow-x-hidden">
                <div id="main-content" tabindex="-1">
                    {{ $slot }}
                </div>
            </main>
        </div>

        {{-- Bottom navigation (mobile only) --}}
        @auth
            <x-mobile-bottom-nav />
        @endauth

        {{-- Mount point para el sistema global de toasts (Vue app separada en resources/js/app.js) --}}
        <div id="toast-root"></div>

        {{-- Mount point para el banner de "nueva version disponible" --}}
        <div id="update-prompt-root"></div>

        {{-- Mount point para el temporizador de descanso global (Pinia restTimer) --}}
        <div id="rest-timer-root"></div>

        {{-- Mount point para el indicador de estado offline global --}}
        <div id="offline-status-root"></div>

        {{-- Dark mode manager (expone window.darkMode, lo consume el componente Vue app-navigation) --}}
        <script>
            (function () {
                const STORAGE_KEY = 'theme_mode'; // nueva key: 'auto' | 'light' | 'dark'
                const LEGACY_KEY = 'theme';      // vieja key: 'light' | 'dark'
                const root = document.documentElement;
                function setStored(v) { try { localStorage.setItem(STORAGE_KEY, v); } catch (e) {} }
                function prefersDark() { return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches; }
                function effectiveDark() {
                    var mode = localStorage.getItem(STORAGE_KEY);
                    if (!mode) {
                        // retrocompat: si la vieja key está, usarla
                        var legacy = localStorage.getItem(LEGACY_KEY);
                        if (legacy === 'dark') return true;
                        if (legacy === 'light') return false;
                        return prefersDark();
                    }
                    return mode === 'dark' || (mode === 'auto' && prefersDark());
                }
                function apply() {
                    if (effectiveDark()) root.classList.add('dark');
                    else root.classList.remove('dark');
                }
                window.darkMode = {
                    isDark: () => root.classList.contains('dark'),
                    toggle() {
                        const next = !root.classList.contains('dark');
                        apply();
                        setStored(next ? 'dark' : 'light');
                        window.dispatchEvent(new CustomEvent('theme:changed', { detail: { dark: next } }));
                    },
                };
                // Reaccionar a cambios del sistema cuando el user eligió 'auto'
                if (window.matchMedia) {
                    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', apply);
                }
            })();
        </script>

        {{-- Auto-ocultar avisos "Saved." (antes lo hacia Alpine con x-init + x-show) --}}
        <script>
            (function () {
                document.addEventListener('DOMContentLoaded', function () {
                    document.querySelectorAll('[data-auto-hide-ms]').forEach(function (el) {
                        var ms = parseInt(el.getAttribute('data-auto-hide-ms'), 10) || 2000;
                        setTimeout(function () {
                            el.style.opacity = '0';
                            setTimeout(function () {
                                el.remove();
                            }, 300);
                        }, ms);
                    });
                });
            })();
        </script>
    </body>
</html>